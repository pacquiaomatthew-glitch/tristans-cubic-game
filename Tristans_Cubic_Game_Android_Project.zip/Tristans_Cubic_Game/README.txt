TRISTAN'S CUBIC GAME — ANDROID APP PROJECT
By: FCorbs

Renamed from Fro's Cube Lab. Includes a custom colorful 3D cube launcher icon.

FEATURES
- Menu with PLAY button
- 2x2, 3x3, 4x4 and 5x5 3D cubes
- Face turns, randomize/scramble, reset and auto-solve
- Seven-step beginner tutorial
- Sound effects and 3D view rotation
- Offline operation

AUTO-SOLVER LIMITATION
It reverses move history recorded inside the app. It solves scrambles and turns made inside this app, but does not scan an external physical cube or solve arbitrary states without move history.

BUILD APK
1. Install Android Studio on a computer.
2. Open the TristansCubicGame folder.
3. Allow Gradle sync and install SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Share the generated APK.

The first Gradle sync needs internet to download build plugins. The finished app runs offline.
